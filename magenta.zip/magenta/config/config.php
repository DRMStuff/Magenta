<?php
$rConfig = Array(
    "video_port" => 19000,
    "segments_sling" => 10,
);
