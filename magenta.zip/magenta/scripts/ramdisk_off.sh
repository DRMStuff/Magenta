sudo sed -i '/home\/magenta/d' /etc/fstab
sleep 2
sudo mount -av