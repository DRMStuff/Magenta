#! /bin/bash
sudo killall -9 -u magenta nginx
sudo killall -9 -u magenta php-fpm
sudo killall -9 -u magenta ffmpeg
sudo killall -9 -u magenta php
sudo rm -rf /home/magenta/video/*
sudo rm -rf /home/magenta/hls/*
sudo rm -f /home/magenta/cache/*.db
sudo rm -f /home/magenta/php/daemon.sock