rm /home/magenta/logs/error.log
cd /home/magenta/logs/build/ && find . -name "*.log" -print0 | xargs -0 rm
cd /home/magenta/logs/ffmpeg/ && find . -name "*.log" -print0 | xargs -0 rm
rm /home/magenta/tmp/*.txt
