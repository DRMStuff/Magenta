#! /bin/bash
sudo chown -R magenta:magenta /home/magenta
sudo killall -9 -u magenta nginx
sudo killall -9 -u magenta php-fpm
sudo killall -9 -u magenta ffmpeg
sudo killall -9 -u magenta php
sleep 3
sudo killall -9 -u magenta nginx
sudo killall -9 -u magenta php-fpm
sudo killall -9 -u magenta ffmpeg
sudo killall -9 -u magenta php
sleep 3
sudo rm -rf /home/magenta/video/*
sudo rm -rf /home/magenta/hls/*
sudo rm -f /home/magenta/cache/*.db
sudo rm -f /home/magenta/php/daemon.sock
sudo -u magenta /home/magenta/nginx/sbin/nginx
sudo -u magenta start-stop-daemon --start --quiet --pidfile /home/magenta/php/daemon.pid --exec /home/magenta/php/sbin/php-fpm -- --daemonize --fpm-config /home/magenta/php/etc/daemon.conf
sudo -u magenta /home/magenta/php/bin/php /home/magenta/includes/restore.php