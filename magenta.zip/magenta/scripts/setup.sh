adduser --system --shell /bin/false --group --disabled-login magenta
chown -R magenta:magenta /home/magenta
apt-get -y install libxslt1-dev nscd htop libonig-dev libzip-dev software-properties-common aria2
add-apt-repository ppa:xapienz/curl34 -y
apt-get update
apt-get install libcurl4 curl
wget -q -O /tmp/libpng12.deb http://mirrors.kernel.org/ubuntu/pool/main/libp/libpng/libpng12-0_1.2.54-1ubuntu1_amd64.deb
dpkg -i /tmp/libpng12.deb
apt-get install -y
rm /tmp/libpng12.deb
chmod +x /home/magenta/bin/ffmpeg
chmod +x /home/magenta/bin/mp4decrypt
chmod +x /home/magenta/php/bin/php
chmod +x /home/magenta/php/sbin/php-fpm
chmod +x /home/magenta/nginx/sbin/nginx
ufw allow 19000
ufw allow 19001